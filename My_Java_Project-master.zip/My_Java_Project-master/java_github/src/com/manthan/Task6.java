package com.manthan;

public class Task6 {
	  public static void main(String[] args) {
	       String sentence = "I love learning Java programming";
	        
	        
	        if (sentence.contains("Java")) {
	            System.out.println("The word 'Java' is present in the sentence.");
	        } else {
	            System.out.println("The word 'Java' is NOT present in the sentence.");
	        }
	    }
	}


