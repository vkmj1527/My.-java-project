package com.manthan;
public class FinalKeyword 
{
	public static void main(String[] args) {
		final int BirthYear = 2010;
		System.out.println(BirthYear);
		
	}
}
