package com.manthan;

public class WrapperExample2 {

	public static void main(String[] args) {

			Integer i = 10;   //Java 9 updated.
			System.out.println(i);
			
		}

	}


