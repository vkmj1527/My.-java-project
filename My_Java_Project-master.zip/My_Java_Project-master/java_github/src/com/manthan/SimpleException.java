package com.manthan;

public class SimpleException {
	public static void main(String[] args) {
		int x = 2/0; // Exception (Problem).
		System.out.println("Hello S");
		}
	}

