package com.manthan;

public class If_Else {
	
	public static void main(String[] args) {
			boolean b = true;
			if (b) {
				System.out.println("Its Raining... Take Umbrella");
			} else {
				System.out.println("Don't Take Umbrella");
			}
		

	}

}
