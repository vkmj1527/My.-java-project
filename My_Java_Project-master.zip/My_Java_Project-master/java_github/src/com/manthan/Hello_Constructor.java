package com.manthan;

public class Hello_Constructor {

    
    Hello_Constructor() {
        System.out.println("Hello");
    }

    public static void main(String[] args) {
       
        new Hello_Constructor();
    }
}
