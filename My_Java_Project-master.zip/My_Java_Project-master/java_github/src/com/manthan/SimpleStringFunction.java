package com.manthan;

public class SimpleStringFunction {
	public static void main(String[] args) {
		String magic = "Yuvraj";
		
		System.out.println(magic.charAt(2));
	}
}
