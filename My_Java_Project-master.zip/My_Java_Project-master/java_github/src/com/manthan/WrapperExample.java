package com.manthan;

public class WrapperExample {
	public static void main(String[] args) {
		int a = 10;
		
		Integer obj = Integer.valueOf(a);
		System.out.println(a);
		
	}
		
}
