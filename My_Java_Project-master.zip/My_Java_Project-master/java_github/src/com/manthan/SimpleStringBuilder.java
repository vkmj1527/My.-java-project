package com.manthan;

public class SimpleStringBuilder {
	public static void main(String[] args) {
		StringBuilder obj = new StringBuilder();
		obj.append("Salmon");
		obj.append(" " +"Bhoi");
		
		System.out.println(obj);

	}
}
