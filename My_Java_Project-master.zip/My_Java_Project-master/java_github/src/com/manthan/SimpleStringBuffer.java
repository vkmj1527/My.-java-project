package com.manthan;

public class SimpleStringBuffer {

	public static void main(String[] args) {
		StringBuffer obj = new StringBuffer();
		obj.append("Salmon");
		obj.append(" " +"Bhoi");
		
		System.out.println(obj);

	}

}
