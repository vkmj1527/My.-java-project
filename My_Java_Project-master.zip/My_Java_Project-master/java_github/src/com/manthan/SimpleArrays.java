package com.manthan;

public class SimpleArrays {
	public static void main(String[] args) {
		int[] numbers = {10, 20, 30, 40, 50};
		String[] names = {"Yuvi","Sonu","Shrau","Grace","Aarya"};
		System.out.println(numbers[1]);
		System.out.println(names[1]);
	}
}
