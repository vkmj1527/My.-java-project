package com.manthan;

public class Task8 {
	public static void main(String[] args) {
		StringBuffer obj = new StringBuffer();
		obj.append("Coding");
		obj.append(" ");
		obj.append("is");
		obj.append(" ");
		obj.append("fun");
		
		System.out.println(obj);

	}
}
