package com.manthan;

public class Robot {
	public void hello() {
		System.out.println("Hello, How Are You !");
	}
	
	public static void main(String[] args) {
		
		Robot obj = new Robot();
		obj.hello();
	}
}

