package com.manthan;

public class Task7 {
	public static void main(String[] args) {
		StringBuilder obj = new StringBuilder();
		obj.append("Good");
		obj.append(" ");
		obj.append("Morning");
		
		System.out.println(obj);

	}
}
